# Jijiga Express Upgrade — Implementation Report

## Completed in this phase

The existing Jijiga Express project was inspected and preserved as the base. No working role, dispatch, tracking, inventory, accounting, EEU, parcel, ride, support, or Firestore security behavior was removed.

The following customer-experience improvements are now implemented:

1. A BANA/Marhaba-inspired Food Discovery layer on the customer home screen.
2. Search for food, drinks, products, and vendors.
3. Category cards for Restaurant & Drinks, Bakery & Sweets, Fresh Produce, and Dairy & Essentials.
4. Featured available products section.
5. Popular local vendors section with ratings.
6. Vendor-name search support in addition to product-name and description search.
7. Customer-facing sort controls for Featured, Top Rated Vendors, Lowest Price, and Most Available.
8. A dedicated implementation plan in `plan.md`.
9. A concrete upgrade task list in `TODO.md`.

## Validation

- `npm run typecheck`: PASS
- `npm run build`: PASS
- `npm test`: PASS, 7/7 regression checks

The production build still reports the existing large-chunk warning and the existing Google Maps static/dynamic import warning. Neither prevents a successful build.

## Deliberately not implemented yet

The following require coordinated data-model, security-rule, backend, and UI work and should be implemented in the next phases:

- Phone OTP authentication for +251 and +252
- Real multi-item cart and CartItem persistence
- Server-authoritative checkout totals and idempotency
- Delivery polygons and serviceability enforcement
- Food result filters for distance, ETA, delivery fee, minimum order, and open/closed status
- Unified mobile bottom navigation
- Hotel booking models and reservation rules
- Loyalty ledger and tier rules
- Categorized Help Center tickets
- Online-payment provider adapter

Gas delivery is intentionally excluded from the product scope.

## Risk notes

The project currently has a broad multi-service domain model. Large changes to `Order`, Firestore rules, payment states, or role transitions must be introduced through backward-compatible migrations. COD remains the trusted payment path until a signed payment backend is added.
