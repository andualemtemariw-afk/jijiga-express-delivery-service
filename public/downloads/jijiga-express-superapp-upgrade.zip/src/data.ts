import { Batch, Mamila } from './types';

export const CITIES = [
  { id: 'jijiga', name: 'Jijiga', region: 'Somali Region, Ethiopia', defaultPlusCode: '8F2P+5H Jijiga' },
  { id: 'hargeisa', name: 'Hargeisa', region: 'Maroodi Jeex, Somaliland', defaultPlusCode: 'H654+7G Hargeisa' },
  { id: 'diredawa', name: 'Dire Dawa', region: 'Dire Dawa Administration', defaultPlusCode: 'HVM8+8Q Dire Dawa' },
  { id: 'harar', name: 'Harar', region: 'Harari Region', defaultPlusCode: 'CQ8R+5P Harar' },
  { id: 'addis', name: 'Addis Ababa', region: 'Federal Capital', defaultPlusCode: 'XQVP+8M Addis Ababa' },
];

export const MAMILAS: Mamila[] = [
  { 
    id: 'm1', 
    name: 'Fresh Morning Farms', 
    rating: 4.8, 
    location: 'Bole / North Greenbelt, Jijiga', 
    plusCode: 'XQVP+8M', 
    phone: '+251 91 234 5678', 
    coordinates: { lat: 9.3620, lng: 42.8020 },
    category: 'Farm & Grocer'
  },
  { 
    id: 'm2', 
    name: 'Arada Bakery', 
    rating: 4.9, 
    location: 'Piassa & Central Square, Jijiga', 
    plusCode: 'XR2M+9R', 
    phone: '+251 92 345 6789', 
    coordinates: { lat: 9.3510, lng: 42.7915 },
    category: 'Bakery & Sweets'
  },
  { 
    id: 'm3', 
    name: 'Sheger Dairy', 
    rating: 4.7, 
    location: 'Kazanchis Sector, Jijiga', 
    plusCode: 'XQWG+2P', 
    phone: '+251 93 456 7890', 
    coordinates: { lat: 9.3470, lng: 42.8045 },
    category: 'Dairy'
  },
  { 
    id: 'm4', 
    name: 'Hassan Wali Hotel & Restaurant', 
    rating: 4.9, 
    location: 'Taiwan Market Road, Jijiga & Hargeisa', 
    plusCode: '8F3Q+4W', 
    phone: '+251 91 456 7891', 
    coordinates: { lat: 9.3580, lng: 42.7980 },
    category: 'Hotel & Restaurant'
  },
  { 
    id: 'm5', 
    name: 'Jijiga Express Fresh Kitchen & Food', 
    rating: 4.8, 
    location: 'Main Commercial Ave, Jijiga', 
    plusCode: '8F2P+9X', 
    phone: '+251 91 789 0123', 
    coordinates: { lat: 9.3530, lng: 42.7930 },
    category: 'Hotel & Restaurant'
  },
  { 
    id: 'khat_m1', 
    name: 'Mamila Halimo (Aweday Prime Direct)', 
    rating: 4.9, 
    location: 'Taiwan Market Gate 2, Jijiga', 
    plusCode: '8F2P+6V', 
    phone: '+251 91 555 1234', 
    coordinates: { lat: 9.3540, lng: 42.7950 },
    category: 'Khat Vendor (Mamila)',
    khatSpecialty: 'Direct Aweday Abo Mismar & Urji',
    dailyArrivalTime: '10:30 AM & 2:00 PM Fresh Shipments',
    trustedBadges: ['Verified Mamila', 'Direct Aweday Supply', 'Moist Leaf Guarantee'],
    stallNumber: 'Stall #14A',
    verifiedDirectFarm: true
  },
  { 
    id: 'khat_m2', 
    name: 'Mamila Deeqo (Gursum Gold & Urji)', 
    rating: 4.8, 
    location: 'Old Bus Terminal Road, Jijiga', 
    plusCode: '8F2P+7T', 
    phone: '+251 92 666 5678', 
    coordinates: { lat: 9.3515, lng: 42.7920 },
    category: 'Khat Vendor (Mamila)',
    khatSpecialty: 'Gursum Highland Tender Leaf',
    dailyArrivalTime: '11:00 AM Daily Arrival',
    trustedBadges: ['Trusted Vendor', '15+ Years Experience', 'Banana Leaf Wrap'],
    stallNumber: 'Stall #08',
    verifiedDirectFarm: true
  },
  { 
    id: 'khat_m3', 
    name: 'Mamila Saynab (Harari Behati Select)', 
    rating: 4.9, 
    location: 'Commercial Avenue, Jijiga', 
    plusCode: '8F3Q+2M', 
    phone: '+251 93 777 9012', 
    coordinates: { lat: 9.3565, lng: 42.7975 },
    category: 'Khat Vendor (Mamila)',
    khatSpecialty: 'Harari Behati & Gelemso Sweet Leaf',
    dailyArrivalTime: '11:30 AM & 3:30 PM Fresh Shipments',
    trustedBadges: ['Top Rated in Somali Region', 'Curated Batch Selection'],
    stallNumber: 'Stall #22B',
    verifiedDirectFarm: true
  },
  { 
    id: 'khat_m4', 
    name: 'Mamila Fartun (Central Taiwan Hub)', 
    rating: 4.7, 
    location: 'Near Grand Mosque, Central Jijiga', 
    plusCode: '8F2P+4J', 
    phone: '+251 91 888 3456', 
    coordinates: { lat: 9.3525, lng: 42.7940 },
    category: 'Khat Vendor (Mamila)',
    khatSpecialty: 'Fast Handover, Value Bundles & Fresh Urji',
    dailyArrivalTime: 'Continuous Fresh Stock',
    trustedBadges: ['Fastest Dispatch', 'Express Delivery'],
    stallNumber: 'Stall #03',
    verifiedDirectFarm: true
  },
];

export const INITIAL_BATCHES: Batch[] = [
  {
    id: 'b1',
    mamilaId: 'm1',
    name: 'Organic Veggie Bundle',
    description: 'Freshly harvested vine tomatoes, red shallots, spinach (gomen), and garden herbs.',
    price: 450,
    available: 15,
    expiry: 'Today, 6:00 PM',
    imageUrl: '/src/assets/images/fresh_produce_bundle_1790430925858.jpg',
    category: 'Fresh Farm Produce',
    unit: '1 harvest basket (~3.5 kg)',
    harvestTime: 'Picked today at 5:45 AM',
  },
  {
    id: 'b2',
    mamilaId: 'm2',
    name: 'Morning Pastry Box',
    description: 'Freshly baked artisanal bread loaf, flaky butter croissants, and sesame buns.',
    price: 320,
    available: 8,
    expiry: 'Today, 2:00 PM',
    imageUrl: '/src/assets/images/artisan_pastry_box_1790430934857.jpg',
    category: 'Bakery & Pastries',
    unit: '1 bakery box (6 assorted items)',
    harvestTime: 'Oven fresh at 6:15 AM',
  },
  {
    id: 'b3',
    mamilaId: 'm3',
    name: 'Dairy Essentials Pack',
    description: 'Pasteurized pure whole cow milk (2L), traditional fresh Ayib cheese, and clarified butter.',
    price: 650,
    available: 5,
    expiry: 'Tomorrow, 10:00 AM',
    imageUrl: '/src/assets/images/dairy_farm_essentials_1790430944133.jpg',
    category: 'Dairy & Eggs',
    unit: '1 cold pack (3 farm items)',
    harvestTime: 'Packed today at 6:00 AM',
  },
  {
    id: 'b4',
    mamilaId: 'm4',
    name: 'Signature Babay Cold Drink & Lime',
    description: 'Refreshing chilled crushed fruit mocktail with fresh mint, lime slices, and crushed ice.',
    price: 120,
    available: 24,
    expiry: 'Freshly prepared on order',
    imageUrl: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=800&auto=format&fit=crop&q=80',
    category: 'Restaurant & Drinks',
    unit: '1 large chilled glass (500ml)',
    harvestTime: 'Freshly blended on demand',
  },
  {
    id: 'b5',
    mamilaId: 'm5',
    name: 'Chilled Sprite (Twin 330ml Pack)',
    description: 'Crisp, ice-cold lemon-lime soda bottles. Perfect thirst quencher.',
    price: 120,
    available: 30,
    expiry: 'Chilled ready for dispatch',
    imageUrl: 'https://images.unsplash.com/photo-1625772299848-391b6a87d7b3?w=800&auto=format&fit=crop&q=80',
    category: 'Restaurant & Drinks',
    unit: '2 x 330ml chilled bottles',
    harvestTime: 'Refrigerated depot storage',
  },
  {
    id: 'b6',
    mamilaId: 'm4',
    name: 'Hilib Geel & Spiced Rice Platter',
    description: 'Tender Somali-style roasted camel meat served over fragrant cardamom basmati rice with banana.',
    price: 380,
    available: 12,
    expiry: 'Lunch & Dinner Special',
    imageUrl: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=800&auto=format&fit=crop&q=80',
    category: 'Hotel & Restaurant',
    unit: '1 hearty entree platter (~600g)',
    harvestTime: 'Cooked fresh daily',
  },
  {
    id: 'kb1',
    mamilaId: 'khat_m1',
    name: 'Abo Mismar (Prime Grade Aweday)',
    description: 'Crisp, tender red tips harvested at dawn in Aweday highlands. Wrapped in fresh moist banana leaf for maximum succulence.',
    price: 850,
    available: 24,
    expiry: 'Fresh Morning Transport (Arrived 10:45 AM)',
    imageUrl: '/src/assets/images/fresh_khat_bundle_1790872116314.jpg',
    category: 'Khat Marketplace',
    unit: '1 bundle (~550g wrapped)',
    harvestTime: 'Transported fresh from Aweday at 10:45 AM',
    khatGrade: 'Abo Mismar (Prime)',
    leafMoisture: 'Crisp moist tender tips, highest alkaloid profile',
    bundleWrapType: 'Fresh Banana Leaf'
  },
  {
    id: 'kb2',
    mamilaId: 'khat_m2',
    name: 'Urji Fresh Leaf (Gursum Morning Batch)',
    description: 'High-moisture soft young foliage cultivated in Gursum. Gentle flavor and smooth texture, carefully inspected.',
    price: 650,
    available: 18,
    expiry: 'Fresh Arrival (Arrived 11:15 AM)',
    imageUrl: '/src/assets/images/fresh_khat_bundle_1790872116314.jpg',
    category: 'Khat Marketplace',
    unit: '1 tender bundle (~480g)',
    harvestTime: 'Early morning harvest at 6:15 AM',
    khatGrade: 'Urji Fresh Leaf',
    leafMoisture: 'Plump succulent green leaves, tender stems',
    bundleWrapType: 'Fresh Banana Leaf'
  },
  {
    id: 'kb3',
    mamilaId: 'khat_m3',
    name: 'Harari Behati Select Reserve',
    description: 'Elite Harar ancient terraced harvest. Hand-selected for VIP gatherings, connoisseur grade aroma and crisp bite.',
    price: 980,
    available: 12,
    expiry: 'Daily Limited Batch',
    imageUrl: '/src/assets/images/fresh_khat_bundle_1790872116314.jpg',
    category: 'Khat Marketplace',
    unit: '1 curated bundle (~600g)',
    harvestTime: 'Picked 7:00 AM, arrived in Jijiga 11:30 AM',
    khatGrade: 'Harari Behati',
    leafMoisture: 'Premium select grade, wrapped in damp palm fiber',
    bundleWrapType: 'Traditional Palm Fiber'
  },
  {
    id: 'kb4',
    mamilaId: 'khat_m1',
    name: 'Gelemso Special Afternoon Batch',
    description: 'Sweet, mellow foliage with balanced character. Perfect for long afternoon sessions and friendly circles.',
    price: 750,
    available: 20,
    expiry: 'Fresh Afternoon Harvest',
    imageUrl: '/src/assets/images/fresh_khat_bundle_1790872116314.jpg',
    category: 'Khat Marketplace',
    unit: '1 standard bundle (~500g)',
    harvestTime: 'Fresh afternoon arrival 1:15 PM',
    khatGrade: 'Gelemso Special',
    leafMoisture: 'Sweet pleasant aroma, medium leaf texture',
    bundleWrapType: 'Moist Burlap Wrap'
  },
  {
    id: 'kb5',
    mamilaId: 'khat_m4',
    name: 'Central Taiwan Daily Fresh Urji',
    description: 'Popular everyday fresh batch with reliable consistency. Cut fresh and tied tight for speedy direct delivery.',
    price: 520,
    available: 30,
    expiry: 'Today, all-day supply',
    imageUrl: '/src/assets/images/fresh_khat_bundle_1790872116314.jpg',
    category: 'Khat Marketplace',
    unit: '1 compact bundle (~420g)',
    harvestTime: 'Fresh morning stock 9:00 AM',
    khatGrade: 'Urji Fresh Leaf',
    leafMoisture: 'Crisp green leaves, traditional tie',
    bundleWrapType: 'Fresh Banana Leaf'
  }
];

export const SERVICEABILITY_ZONES: Record<string, { isServiceable: boolean; zoneName: string; baseFee: number; etaMins: number; minOrderEtb: number; reason?: string }> = {
  Jijiga: {
    isServiceable: true,
    zoneName: 'Jijiga Urban & Kebele Metro (Kebeles 01 - 20)',
    baseFee: 60,
    etaMins: 25,
    minOrderEtb: 150,
  },
  Hargeisa: {
    isServiceable: true,
    zoneName: 'Hargeisa Central & Airport Corridor',
    baseFee: 80,
    etaMins: 35,
    minOrderEtb: 200,
  },
  'Dire Dawa': {
    isServiceable: true,
    zoneName: 'Dire Dawa Administration Corridor',
    baseFee: 70,
    etaMins: 30,
    minOrderEtb: 180,
  },
  Harar: {
    isServiceable: true,
    zoneName: 'Harar Historical Old Town & Greenbelt',
    baseFee: 75,
    etaMins: 35,
    minOrderEtb: 180,
  },
  'Addis Ababa': {
    isServiceable: true,
    zoneName: 'Addis Ababa Bole & Central District',
    baseFee: 120,
    etaMins: 45,
    minOrderEtb: 250,
  },
  'Remote Somali Region Outskirts': {
    isServiceable: false,
    zoneName: 'Remote Pastoral Corridor',
    baseFee: 0,
    etaMins: 0,
    minOrderEtb: 0,
    reason: 'Active delivery couriers are not currently stationed in this outskirts sector.',
  },
};

export const HOTELS_DATA = [
  {
    id: 'h1',
    name: 'Hassan Wali Hotel & Executive Suites',
    city: 'Jijiga',
    location: 'Taiwan Commercial Avenue, Kebele 04, Jijiga',
    rating: 4.9,
    reviewCount: 142,
    priceRange: '1,800 - 4,200 ETB / night',
    coverImage: '/src/assets/images/khat_mamila_stall_1790872127551.jpg',
    amenities: ['High-speed Wi-Fi', 'Air Conditioning', 'Smart Satellite TV', 'Prayer Room', '24/7 Generator', 'Executive Lounge', 'Secure Parking'],
    phone: '+251 91 456 7891',
    checkInTime: '2:00 PM',
    checkOutTime: '11:30 AM',
    featured: true,
    roomTypes: [
      {
        id: 'r1',
        name: 'Deluxe Queen Room',
        pricePerNight: 1850,
        bedType: '1 Queen Bed',
        maxGuests: 2,
        availableRooms: 5,
        amenities: ['Wi-Fi', 'AC', 'Private Bath', 'Breakfast included'],
      },
      {
        id: 'r2',
        name: 'Executive Suite with City View',
        pricePerNight: 3400,
        bedType: '1 King Bed + Sitting Area',
        maxGuests: 3,
        availableRooms: 3,
        amenities: ['Wi-Fi', 'AC', 'Panoramic View', 'Workspace', 'Breakfast included'],
      },
    ],
  },
  {
    id: 'h2',
    name: 'Mansoor Hotel & Conference Hall',
    city: 'Hargeisa',
    location: 'Airport Highway & Diplomatic Sector, Hargeisa',
    rating: 4.8,
    reviewCount: 98,
    priceRange: '2,200 - 5,500 ETB / night',
    coverImage: '/src/assets/images/fresh_produce_bundle_1790430925858.jpg',
    amenities: ['Fiber Wi-Fi', 'Conference Center', 'Fine Dining Restaurant', 'Prayer Facilities', 'Airport Shuttle', '24/7 Security'],
    phone: '+252 63 422 1199',
    checkInTime: '1:00 PM',
    checkOutTime: '12:00 PM',
    featured: true,
    roomTypes: [
      {
        id: 'r3',
        name: 'Standard Business Room',
        pricePerNight: 2400,
        bedType: '1 King Bed',
        maxGuests: 2,
        availableRooms: 6,
        amenities: ['Wi-Fi', 'Work Desk', 'En-suite Bathroom'],
      },
      {
        id: 'r4',
        name: 'Diplomatic Diplomat Suite',
        pricePerNight: 4800,
        bedType: '1 Super King Bed + Conference Desk',
        maxGuests: 2,
        availableRooms: 2,
        amenities: ['Airport Pickup', 'Breakfast Buffet', 'VIP Lounge Access'],
      },
    ],
  },
  {
    id: 'h3',
    name: 'Central Plaza Boutique Hotel',
    city: 'Jijiga',
    location: 'Central Plaza Square, Kebele 06, Jijiga',
    rating: 4.7,
    reviewCount: 76,
    priceRange: '1,400 - 2,800 ETB / night',
    coverImage: '/src/assets/images/dairy_farm_essentials_1790430944133.jpg',
    amenities: ['Fast Wi-Fi', 'Cafeteria & Terrace', 'Air Conditioning', 'Free Parking', '24/7 Front Desk'],
    phone: '+251 92 888 3456',
    checkInTime: '2:00 PM',
    checkOutTime: '11:00 AM',
    featured: false,
    roomTypes: [
      {
        id: 'r5',
        name: 'Single Cozy Studio',
        pricePerNight: 1450,
        bedType: '1 Double Bed',
        maxGuests: 1,
        availableRooms: 8,
        amenities: ['Wi-Fi', 'Hot Shower', 'Cable TV'],
      },
      {
        id: 'r6',
        name: 'Double Comfort Room',
        pricePerNight: 2200,
        bedType: '2 Twin Beds',
        maxGuests: 2,
        availableRooms: 4,
        amenities: ['Wi-Fi', 'Balcony', 'Breakfast included'],
      },
    ],
  },
];

export interface HotelRoomType {
  id?: string;
  type: string;
  name?: string;
  pricePerNight: number;
  bedType?: string;
  capacity?: number;
  maxGuests?: number;
  availableRooms?: number;
  amenities?: string[];
  features?: string[];
  description?: string;
}

export interface RegionalHotel {
  id: string;
  name: string;
  city: string;
  location: string;
  rating: number;
  reviewsCount: number;
  reviewCount?: number;
  priceRange?: string;
  imageUrl?: string;
  coverImage?: string;
  amenities: string[];
  phone?: string;
  checkInTime?: string;
  checkOutTime?: string;
  featured?: boolean;
  roomTypes: HotelRoomType[];
}

export const REGIONAL_HOTELS: RegionalHotel[] = HOTELS_DATA.map((h) => ({
  ...h,
  reviewsCount: h.reviewCount,
  imageUrl: h.coverImage,
  roomTypes: h.roomTypes.map((r) => ({
    ...r,
    type: r.name,
    capacity: r.maxGuests,
    features: r.amenities,
    description: `${r.bedType} • Max ${r.maxGuests} guests • ${r.amenities.join(', ')}`,
  })),
}));

export interface GroceryMarketItem {
  id: string;
  name: string;
  category: string;
  price: number;
  unit: string;
  weightKg: number;
  origin: string;
  marketName: string;
  stallNumber: string;
  vendorName: string;
  freshnessGuarantee: string;
  imageUrl?: string;
  description?: string;
  stock?: number;
}

export const GROCERY_MARKET_ITEMS: GroceryMarketItem[] = [
  {
    id: 'groc_camel_milk',
    name: 'Fresh Raw Camel Milk (Caano Geel)',
    category: 'Camel Milk & Dairy',
    price: 320,
    unit: '2L Chilled Jug',
    weightKg: 2.0,
    origin: 'Fafan Valley Pastures, Somali Region',
    marketName: 'Taiwan Market Food Terminal',
    stallNumber: 'Dairy Stalls #14',
    vendorName: 'Mama Cawo Pastoral Co-op',
    freshnessGuarantee: 'Milked at 5:00 AM, refrigerated transport',
    imageUrl: '/src/assets/images/dairy_farm_essentials_1790430944133.jpg',
    description: 'Pure organic camel milk freshly delivered daily from pastoral herds in Fafan Valley.',
    stock: 25,
  },
  {
    id: 'groc_jijiga_berbere',
    name: 'Artisan Somali Spiced Berbere Blend',
    category: 'Spices & Berbere',
    price: 280,
    unit: '1 kg sealed pouch',
    weightKg: 1.0,
    origin: 'Hand-ground in Harar & Jijiga',
    marketName: 'Old Central Spice Souq',
    stallNumber: 'Spice Alley #08',
    vendorName: 'Asha Spice House',
    freshnessGuarantee: 'Stone-ground this week, sun-dried chilies',
    imageUrl: '/src/assets/images/fresh_produce_bundle_1790430925858.jpg',
    description: 'Traditional slow-roasted chili and herb berbere spice blend, ground by hand with korarima and fenugreek.',
    stock: 40,
  },
  {
    id: 'groc_white_teff',
    name: 'Magna White Teff Flour (First Grade)',
    category: 'Grains & Staples',
    price: 950,
    unit: '10 kg woven sack',
    weightKg: 10.0,
    origin: 'Bishoftu / East Shewa Highlands',
    marketName: 'Taiwan Market Grain Depot',
    stallNumber: 'Grain Pavilion #33',
    vendorName: 'Hodan Grain Wholesalers',
    freshnessGuarantee: 'Triple-sifted, moisture inspected',
    imageUrl: '/src/assets/images/fresh_produce_bundle_1790430925858.jpg',
    description: 'Premium snow-white Magna teff grain, triple-sifted and milled for feather-light injera fermentation.',
    stock: 18,
  },
  {
    id: 'groc_red_onions',
    name: 'Awash Valley Red Shallot Onions',
    category: 'Produce',
    price: 380,
    unit: '5 kg mesh bag',
    weightKg: 5.0,
    origin: 'Awash Agricultural Basin',
    marketName: 'Taiwan Market Veg Sector',
    stallNumber: 'Produce Row #19',
    vendorName: 'Farhan Fresh Greenery',
    freshnessGuarantee: 'Harvested within 48h, dry firm bulbs',
    imageUrl: '/src/assets/images/fresh_produce_bundle_1790430925858.jpg',
    description: 'Crisp aromatic red shallots with deep purple skins, ideal for rich stews and everyday cooking.',
    stock: 35,
  },
  {
    id: 'groc_sesame_oil',
    name: 'Pure Cold-Pressed Sesame Oil (Saliid Macaan)',
    category: 'Cooking Oils',
    price: 450,
    unit: '1L glass bottle',
    weightKg: 1.0,
    origin: 'Godey & Shabelle Basin',
    marketName: 'Old Central Spice Souq',
    stallNumber: 'Oil Press #03',
    vendorName: 'Shabelle Pure Oils',
    freshnessGuarantee: 'Cold pressed, unrefined 100% natural',
    imageUrl: '/src/assets/images/dairy_farm_essentials_1790430944133.jpg',
    description: 'Cold expeller-pressed golden sesame oil with a fragrant nutty aroma and zero additives.',
    stock: 22,
  },
  {
    id: 'groc_subag_ghee',
    name: 'Traditional Cultured Cow Ghee (Subag Saafi)',
    category: 'Camel Milk & Dairy',
    price: 680,
    unit: '1 kg sealed tin',
    weightKg: 1.0,
    origin: 'Babile Pastoral Highlands',
    marketName: 'Taiwan Market Dairy Terminal',
    stallNumber: 'Dairy Stalls #18',
    vendorName: 'Fatima Traditional Dairy',
    freshnessGuarantee: 'Simmered with Somali aromatics',
    imageUrl: '/src/assets/images/dairy_farm_essentials_1790430944133.jpg',
    description: 'Rich pasture-fed cow milk butter ghee slowly simmered with cardamom and cloves for authentic flavor.',
    stock: 15,
  },
];


